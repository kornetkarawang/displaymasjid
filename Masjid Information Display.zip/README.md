
  # Masjid Information Display

  This is a code bundle for Masjid Information Display. The original project is available at https://www.figma.com/design/fXjcyCbkfpfaRMfZY8CfNm/Masjid-Information-Display.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  