import { useState, useEffect } from "react";

export function DigitalClock() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const hours = time.getHours().toString().padStart(2, "0");
  const minutes = time.getMinutes().toString().padStart(2, "0");
  const seconds = time.getSeconds().toString().padStart(2, "0");

  return (
    <div className="flex items-center gap-2">
      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-lg px-6 py-4">
        <span className="text-white text-6xl tabular-nums tracking-wider">
          {hours}:{minutes}:{seconds}
        </span>
      </div>
      <span className="text-white/80 text-2xl">WIB</span>
    </div>
  );
}
