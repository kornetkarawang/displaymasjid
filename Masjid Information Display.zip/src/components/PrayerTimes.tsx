import { useState, useEffect } from "react";
import { motion } from "motion/react";

interface PrayerTime {
  name: string;
  time: string;
  isPassed: boolean;
}

export function PrayerTimes() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Mock prayer times - in real app, this would come from an API
  const prayerTimesData = [
    { name: "Subuh", time: "04:45" },
    { name: "Dzuhur", time: "12:10" },
    { name: "Ashar", time: "15:25" },
    { name: "Maghrib", time: "18:15" },
    { name: "Isya", time: "19:30" },
  ];

  const isPrayerPassed = (prayerTime: string) => {
    const [hours, minutes] = prayerTime.split(':').map(Number);
    const currentHours = currentTime.getHours();
    const currentMinutes = currentTime.getMinutes();
    
    if (currentHours > hours) return true;
    if (currentHours === hours && currentMinutes >= minutes) return true;
    return false;
  };

  const prayerTimes: PrayerTime[] = prayerTimesData.map(prayer => ({
    ...prayer,
    isPassed: isPrayerPassed(prayer.time)
  }));

  const getNextPrayer = () => {
    const notPassed = prayerTimes.find(p => !p.isPassed);
    return notPassed?.name || "Subuh";
  };

  const nextPrayer = getNextPrayer();

  return (
    <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8">
      <h2 className="text-white text-3xl text-center mb-6">JADWAL SHOLAT</h2>
      
      <div className="space-y-4">
        {prayerTimes.map((prayer, index) => {
          const isNext = prayer.name === nextPrayer;
          
          return (
            <motion.div
              key={prayer.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`relative flex items-center justify-between p-6 rounded-xl transition-all ${
                isNext 
                  ? 'bg-emerald-500/30 border-2 border-emerald-400 shadow-lg shadow-emerald-500/20' 
                  : 'bg-white/5 border border-white/10'
              }`}
            >
              {isNext && (
                <motion.div
                  className="absolute -left-2 top-1/2 -translate-y-1/2"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <div className="w-4 h-4 bg-emerald-400 rounded-full shadow-lg shadow-emerald-400/50" />
                </motion.div>
              )}
              
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  isNext ? 'bg-emerald-400/30' : 'bg-white/10'
                }`}>
                  <span className={`text-2xl ${isNext ? 'text-emerald-200' : 'text-white/70'}`}>
                    {index + 1}
                  </span>
                </div>
                <span className={`text-3xl ${isNext ? 'text-white' : 'text-white/90'}`}>
                  {prayer.name}
                </span>
              </div>
              
              <div className="flex items-center gap-4">
                {isNext && (
                  <span className="text-emerald-300 text-xl bg-emerald-500/20 px-4 py-2 rounded-lg">
                    Selanjutnya
                  </span>
                )}
                <span className={`text-4xl tabular-nums ${
                  isNext ? 'text-white' : 'text-white/90'
                }`}>
                  {prayer.time}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
