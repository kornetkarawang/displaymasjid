import { DigitalClock } from "./components/DigitalClock";
import { DateDisplay } from "./components/DateDisplay";
import { PrayerTimes } from "./components/PrayerTimes";
import { InfoSlider } from "./components/InfoSlider";

export default function App() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1564769625905-50e93615e769?w=1920&q=80')`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col min-h-screen p-8">
        {/* Header Section */}
        <div className="text-center mb-8">
          <h1 className="text-white text-5xl mb-4">MASJID AL-IKHLAS</h1>
          <div className="flex flex-col items-center gap-4">
            <DigitalClock />
            <DateDisplay />
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          {/* Prayer Times Section - Takes more space */}
          <div className="lg:col-span-2">
            <PrayerTimes />
          </div>

          {/* Info Section */}
          <div className="lg:col-span-1">
            <InfoSlider />
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-white/80">
            "Dan dirikanlah sholat, tunaikanlah zakat dan ruku'lah beserta orang-orang yang ruku'" - QS. Al-Baqarah: 43
          </p>
        </div>
      </div>
    </div>
  );
}
